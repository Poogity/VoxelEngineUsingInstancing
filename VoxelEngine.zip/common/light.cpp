#include <glfw3.h>
#include <iostream>
#include <math.h>
#include <glm/gtc/matrix_transform.hpp>
#include "light.h"


using namespace glm;
//float T = 10; //period of rotation
Light::Light(GLFWwindow* window, glm::vec4 init_direction, glm::vec4 init_color, float init_power) : window(window) {

    power = init_power;
    direction = init_direction;
    base_color = init_color;
    color = init_color;

    // setting near and far plane affects the detail of the shadow
    nearPlane = 1.0;
    farPlane = 10000.0;

    //direction = normalize(targetposition - vec3(direction.x,direction.y,direction.z));

    //targetposition = glm::vec3(0.0, 0.0, -5.0);


    projectionMatrix = ortho(-175.0f, 75.0f, -125.0f, 125.0f, nearPlane, farPlane);
    orthoProj = true;

   
}





void Light::update(vec3 targetPos) {
    
    float angle = acos(dot(vec3(direction), vec3(1, 0, 1)));
    power = glm::max(-direction.y, 0.1f);  //may not be needed once shadows are implemented
    angle = angle * 180 / 3.14159;
    //printf("%f\n", angle);

    if (angle > 120) {          //dawn colors
        color.b = base_color.b - 0.010 * (angle-120);
        color.g = base_color.g - 0.005 * (angle-120);
    }

    if (angle < 60 ) {          //twilight colors 
        color.b = base_color.b - 0.015 * (60 - angle);
        color.g = base_color.g - 0.010 * (60 - angle);
    }

    


    // converting direction to cylidrical coordinates
    float x = direction.x;
    float y = direction.y;
    float z = direction.z;

    // We don't need to calculate the vertical angle
    
    float horizontalAngle;
    if (z > 0.0) horizontalAngle = atan(x/z);
    else if (z < 0.0) horizontalAngle = atan(x/z) + 3.1415f;
    else horizontalAngle = 3.1415f / 2.0f;

    // Right vector
    vec3 right(
        sin(horizontalAngle - 3.14f / 2.0f),
        0,
        cos(horizontalAngle - 3.14f / 2.0f)
    );

    // Up vector
    vec3 up = cross(right, vec3(direction.x,direction.y,direction.z));

    viewMatrix = lookAt(
        normalize(vec3(-direction))*200.0f,
        targetPos, 
        up 
    );
    projectionMatrix = ortho(-175.0f, 175.0f, -150.0f, 150.0f, nearPlane, farPlane);
    //*/

}


mat4 Light::lightVP() {
    return projectionMatrix*viewMatrix;
}