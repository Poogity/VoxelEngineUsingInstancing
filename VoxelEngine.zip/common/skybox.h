#ifndef SKYBOX_H

#define SKYBOX_H

#include <vector> // #include directive
#include <string>

using namespace std;
using namespace glm;



unsigned int loadCubemap(vector<std::string> faces);
void deleteSkybox();
unsigned int loadSkybox();
void drawSkybox(unsigned int cubemapTexture, mat4 MVP);

#endif