#include <glm/glm.hpp>

class Light {
public:

    GLFWwindow* window;
    // Light parameters
    glm::mat4 viewMatrix;
    glm::mat4 projectionMatrix;

    glm::vec4 direction;
    glm::vec4 color;
    glm::vec4 base_color;

    float power;

    float nearPlane;
    float farPlane;

    bool orthoProj;


    // Constructor
    Light(GLFWwindow* window,
        glm::vec4 init_position,
        glm::vec4 init_color,
        float init_power);
  
    void update(glm:: vec3 targetPos);

    glm::mat4 lightVP();
};
