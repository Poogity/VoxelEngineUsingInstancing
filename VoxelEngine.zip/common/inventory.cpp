#include <iostream>
#include <string>
#include <vector>
// Include GLEW
#include <GL/glew.h>
// Include GLFW
#include <glfw3.h>
#include "common/inventory.h"

Inventory::Inventory()
{
	inventory[0] = { BlockType_Stone, 0 };
	inventory[1] = { BlockType_Grass, 0 };
	inventory[2] = { BlockType_Snow, 0 };
	inventory[3] = { BlockType_Bark, 0 };
	inventory[4] = { BlockType_Leaves, 0 };
	slotIndex = 0;
}

void Inventory::addBlock(BlockType m_blockType) {
	for (int i = 0; i < inventorySize; i++) {
		if (inventory[i].m_blockType == m_blockType) {
			inventory[i].m_blockNumber++;
			printf("%d blocks  in slot %d\n", inventory[i].m_blockNumber, i);
		}
	}
}

BlockType Inventory::removeBlock() {
	printf("%d blocks remaining in slot %d\n", std::max(inventory[slotIndex].m_blockNumber - 1, 0), slotIndex);
	if (inventory[slotIndex].m_blockNumber > 0) {
		inventory[slotIndex].m_blockNumber--;
		return inventory[slotIndex].m_blockType;
	}
	else return BlockType_Default;
}

void Inventory::switchSlot() {
	if (slotKeyUnpressed) {
		slotIndex = (slotIndex + 1) % inventorySize;
		printf("switched to slot %d\n", slotIndex);
		slotKeyUnpressed = 0;
	}
}