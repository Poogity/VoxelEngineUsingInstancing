#ifndef INVENTORY_H
#define INVENTORY_H

#include <glm/glm.hpp>
enum BlockType {
    BlockType_Default = 0,
    BlockType_Grass,
    BlockType_Snow,
    BlockType_Stone,
    BlockType_Bark,
    BlockType_Leaves,
};
struct InventorySlot {
    BlockType m_blockType;
    int m_blockNumber;
};

class Inventory
{
public: Inventory();
      void addBlock(BlockType m_blockType);
      BlockType removeBlock();
      void switchSlot();
      bool slotKeyUnpressed = 1;
private:
    InventorySlot inventory[5];
    const int inventorySize = 4;
    int slotIndex;
};

#endif